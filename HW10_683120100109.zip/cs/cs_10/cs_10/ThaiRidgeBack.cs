﻿
using System.Drawing;

namespace cs_10
{
    internal class ThaiRidgeBack
    {
        private Color wHITE_STRIPES;
        private Size mEDIUM;
        private int v1;
        private bool v2;
        private string v3;

        public ThaiRidgeBack(Color wHITE_STRIPES, Size mEDIUM, int v1, bool v2, string v3)
        {
            this.wHITE_STRIPES = wHITE_STRIPES;
            this.mEDIUM = mEDIUM;
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
        }

        internal void Eat()
        {
            throw new NotImplementedException();
        }

        internal void Run()
        {
            throw new NotImplementedException();
        }

        internal void Sound()
        {
            throw new NotImplementedException();
        }
    }
}